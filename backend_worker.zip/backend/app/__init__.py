# Init for app
