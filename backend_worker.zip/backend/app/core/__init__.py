# Init for core
